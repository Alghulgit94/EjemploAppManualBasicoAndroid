package com.example.primerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity { //Nombre de la Clase Principal que hereda de AppCompatActivity

    //Instanciamos nuestros Objetos a utilizar
    EditText etPrimerNum, etSegundoNum; // Inputs de la Clase EditText, los instanciamos bajo esa herencia.
    Button btnCalcular; //Instancia del Botón Calcular.
    TextView txtRespuesta; //Instancia del texto plano de respuesta.

    int primernum, segundonum;

    @Override
    protected void onCreate(Bundle savedInstanceState) { //Método principal que se ejecuta al iniciar la app realizando la carga de todos los componentes
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Se asigna la vista llamando al recurso xml activity_main por medio de la clase R.

        //Con findViewById() enlazamos el objeto JAVA con el componente XML por medio del atributo id mediante la Clase R.
        etPrimerNum = findViewById(R.id.editTextPrimerNum); //Enlace de etPrimerNum
        etSegundoNum = findViewById(R.id.editTextSegundoNum); //Enlace de etSegundoNum
        btnCalcular = findViewById(R.id.buttonCalcular); //Enlace Botón Calcular
        txtRespuesta = findViewById(R.id.textViewRespuesta); //Enlace Respuesta

        btnCalcular.setOnClickListener(calcularMayor); //Registramos el listener del onClick implementado abajo

        }
    // Implementación anónima del Listener OnClick
    private View.OnClickListener calcularMayor = new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                // Se efectúan las operaciones cuando se toca el botón
                if (TextUtils.isEmpty(etPrimerNum.getText().toString())) {//Obtenemos el valor del etPrimerNum y preguntamos si esta vacio con isEmpty()
                    etPrimerNum.setError("Debes ingresar un número");
                    etPrimerNum.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(etSegundoNum.getText().toString())) {//Obtenemos el valor del etPrimerNum y preguntamos si esta vacio con isEmpty()
                   etSegundoNum.setError("Debes ingresar un número");
                   etSegundoNum.requestFocus();
                    return;
                }

                //Traspaso de valores obtenidos desde los inputs para mejor procesamiento
                primernum = Integer.valueOf(etPrimerNum.getText().toString());
                segundonum = Integer.valueOf(etSegundoNum.getText().toString());
                if (primernum == segundonum){
                    txtRespuesta.setText("Los números son Iguales");
                    Toast.makeText(MainActivity.this, "Cálculo Realizado", Toast.LENGTH_SHORT).show();
                }
                if (primernum > segundonum){
                    txtRespuesta.setText("El primer número es el mayor, su valor es: "+primernum);
                    Toast.makeText(MainActivity.this, "Cálculo Realizado", Toast.LENGTH_SHORT).show();
                }
                if (primernum < segundonum){
                    txtRespuesta.setText("El segundo número es el mayor, su valor es: "+segundonum);
                    Toast.makeText(MainActivity.this, "Cálculo Realizado", Toast.LENGTH_SHORT).show();
                }
            }
    };
}
